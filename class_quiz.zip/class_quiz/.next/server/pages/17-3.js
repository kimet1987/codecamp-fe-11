"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/17-3";
exports.ids = ["pages/17-3"];
exports.modules = {

/***/ "./pages/17-3/index.tsx":
/*!******************************!*\
  !*** ./pages/17-3/index.tsx ***!
  \******************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ OpenApi)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! axios */ \"axios\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);\naxios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\nfunction OpenApi() {\n    const { 0: dog , 1: setDog  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(\"\");\n    const onSync = async ()=>{\n        const result = await axios__WEBPACK_IMPORTED_MODULE_1__[\"default\"].get(\"https://dog.ceo/api/breeds/image/random\");\n        setDog(result.data.message);\n        console.log();\n    };\n    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{\n        onSync();\n    }, []);\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"img\", {\n                src: dog\n            }, void 0, false, {\n                fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/pages/17-3/index.tsx\",\n                lineNumber: 19,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: onSync,\n                children: \"클릭!!\"\n            }, void 0, false, {\n                fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/pages/17-3/index.tsx\",\n                lineNumber: 20,\n                columnNumber: 13\n            }, this)\n        ]\n    }, void 0, true));\n};\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8xNy0zL2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBQXlCO0FBQ2tCO0FBRTVCLFFBQVEsQ0FBQ0csT0FBTyxHQUFHLENBQUM7SUFDL0IsS0FBSyxNQUFFQyxHQUFHLE1BQUVDLE1BQU0sTUFBSUgsK0NBQVEsQ0FBQyxDQUFFO0lBQ2pDLEtBQUssQ0FBQ0ksTUFBTSxhQUFlLENBQUM7UUFDeEIsS0FBSyxDQUFDQyxNQUFNLEdBQUcsS0FBSyxDQUFDUCxpREFBUyxDQUMxQixDQUF5QztRQUU3Q0ssTUFBTSxDQUFDRSxNQUFNLENBQUNFLElBQUksQ0FBQ0MsT0FBTztRQUMxQkMsT0FBTyxDQUFDQyxHQUFHO0lBQ2YsQ0FBQztJQUNEWCxnREFBUyxLQUFPLENBQUM7UUFDYkssTUFBTTtJQUNWLENBQUMsRUFBRSxDQUFDLENBQUM7SUFFTCxNQUFNOzt3RkFFR08sQ0FBRztnQkFBQ0MsR0FBRyxFQUFFVixHQUFHOzs7Ozs7d0ZBQ1pXLENBQU07Z0JBQUNDLE9BQU8sRUFBRVYsTUFBTTswQkFBRSxDQUFJOzs7Ozs7OztBQUd6QyxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3NfcXVpei8uL3BhZ2VzLzE3LTMvaW5kZXgudHN4PzVkMGYiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGF4aW9zIGZyb20gXCJheGlvc1wiO1xuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBPcGVuQXBpKCkge1xuICAgIGNvbnN0IFtkb2csIHNldERvZ10gPSB1c2VTdGF0ZShcIlwiKTtcbiAgICBjb25zdCBvblN5bmMgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGF4aW9zLmdldChcbiAgICAgICAgICAgIFwiaHR0cHM6Ly9kb2cuY2VvL2FwaS9icmVlZHMvaW1hZ2UvcmFuZG9tXCJcbiAgICAgICAgKTtcbiAgICAgICAgc2V0RG9nKHJlc3VsdC5kYXRhLm1lc3NhZ2UpO1xuICAgICAgICBjb25zb2xlLmxvZygpO1xuICAgIH07XG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgb25TeW5jKCk7XG4gICAgfSwgW10pO1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPD5cbiAgICAgICAgICAgIDxpbWcgc3JjPXtkb2d9IC8+XG4gICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e29uU3luY30+7YG066atISE8L2J1dHRvbj5cbiAgICAgICAgPC8+XG4gICAgKTtcbn1cbiJdLCJuYW1lcyI6WyJheGlvcyIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiT3BlbkFwaSIsImRvZyIsInNldERvZyIsIm9uU3luYyIsInJlc3VsdCIsImdldCIsImRhdGEiLCJtZXNzYWdlIiwiY29uc29sZSIsImxvZyIsImltZyIsInNyYyIsImJ1dHRvbiIsIm9uQ2xpY2siXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/17-3/index.tsx\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "axios":
/*!************************!*\
  !*** external "axios" ***!
  \************************/
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/17-3/index.tsx"));
module.exports = __webpack_exports__;

})();