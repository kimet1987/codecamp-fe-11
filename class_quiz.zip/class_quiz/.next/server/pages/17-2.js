"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/17-2";
exports.ids = ["pages/17-2"];
exports.modules = {

/***/ "./pages/17-2/index.tsx":
/*!******************************!*\
  !*** ./pages/17-2/index.tsx ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ MyComponent)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nfunction MyComponent() {\n    const { 0: count , 1: setCount  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(0);\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();\n    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{\n        console.log(\"컴포넌트가 마운트됐습니다~\");\n    }, [\n        count\n    ]);\n    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{\n        console.log(\"컴포넌트가 변경됐습니다~\");\n    });\n    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{\n        return ()=>{\n            alert(\"컴포넌트가 제거됩니다~\");\n        };\n    }, [\n        router.route\n    ]);\n    const onClickButton = ()=>{\n        setCount((prev)=>prev + 1\n        );\n    };\n    const onClickMove = ()=>{\n        router.push(\"/\");\n    };\n    console.log(\"마운트 시작\");\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: [\n                    \"카운트: \",\n                    count\n                ]\n            }, void 0, true, {\n                fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/pages/17-2/index.tsx\",\n                lineNumber: 33,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: onClickButton,\n                children: \"카운트(+1)\"\n            }, void 0, false, {\n                fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/pages/17-2/index.tsx\",\n                lineNumber: 34,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: onClickMove,\n                children: \"이동하기\"\n            }, void 0, false, {\n                fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/pages/17-2/index.tsx\",\n                lineNumber: 35,\n                columnNumber: 13\n            }, this)\n        ]\n    }, void 0, true));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8xNy0yL2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUErQztBQUNKO0FBRTVCLFFBQVEsQ0FBQ0csV0FBVyxHQUFHLENBQUM7SUFDbkMsS0FBSyxNQUFFQyxLQUFLLE1BQUVDLFFBQVEsTUFBSUgsK0NBQVEsQ0FBQyxDQUFDO0lBQ3BDLEtBQUssQ0FBQ0ksTUFBTSxHQUFHTixzREFBUztJQUV4QkMsZ0RBQVMsS0FBTyxDQUFDO1FBQ2JNLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLENBQWdCO0lBQ1IsQ0FBdkIsRUFBRSxDQUFDSjtRQUFBQSxLQUFLO0lBQUEsQ0FBQztJQUVWSCxnREFBUyxLQUFPLENBQUM7UUFDYk0sT0FBTyxDQUFDQyxHQUFHLENBQUMsQ0FBZTtJQUNULENBQXJCO0lBRURQLGdEQUFTLEtBQU8sQ0FBQztRQUNiLE1BQU0sS0FBTyxDQUFDO1lBQ1ZRLEtBQUssQ0FBQyxDQUFjO1FBQ0osQ0FBbkI7SUFDTCxDQUFDLEVBQUUsQ0FBQ0g7UUFBQUEsTUFBTSxDQUFDSSxLQUFLO0lBQUEsQ0FBQztJQUVqQixLQUFLLENBQUNDLGFBQWEsT0FBUyxDQUFDO1FBQ3pCTixRQUFRLEVBQUVPLElBQUksR0FBS0EsSUFBSSxHQUFHLENBQUM7O0lBQy9CLENBQUM7SUFFRCxLQUFLLENBQUNDLFdBQVcsT0FBUyxDQUFDO1FBQ3ZCUCxNQUFNLENBQUNRLElBQUksQ0FBQyxDQUFHO0lBQ25CLENBQUM7SUFFRFAsT0FBTyxDQUFDQyxHQUFHLENBQUMsQ0FBUTtJQUNWLE1BQUo7O3dGQUVHTyxDQUFHOztvQkFBQyxDQUFLO29CQUFPWCxLQUFLOzs7Ozs7O3dGQUNmWSxDQUFBO2dCQUFDQyxPQUFPLEVBQUVOLGFBQWE7MEJBQUUsQ0FBTzs7Ozs7O3dGQUNoQ0ssQ0FBQTtnQkFBQ0MsT0FBTyxFQUFFSixXQUFXOzBCQUFFLENBQUk7Ozs7Ozs7O0FBRzlDLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jbGFzc19xdWl6Ly4vcGFnZXMvMTctMi9pbmRleC50c3g/NDdmOCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUm91dGVyLCB7IHVzZVJvdXRlciB9IGZyb20gXCJuZXh0L3JvdXRlclwiO1xuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNeUNvbXBvbmVudCgpIHtcbiAgICBjb25zdCBbY291bnQsIHNldENvdW50XSA9IHVzZVN0YXRlKDApO1xuICAgIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29uc29sZS5sb2coXCLsu7Ttj6zrhIztirjqsIAg66eI7Jq07Yq465CQ7Iq164uI64ukflwiKTtcbiAgICB9LCBbY291bnRdKTtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwi7Lu07Y+s64SM7Yq46rCAIOuzgOqyveuQkOyKteuLiOuLpH5cIik7XG4gICAgfSk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgYWxlcnQoXCLsu7Ttj6zrhIztirjqsIAg7KCc6rGw65Cp64uI64ukflwiKTtcbiAgICAgICAgfTtcbiAgICB9LCBbcm91dGVyLnJvdXRlXSk7XG5cbiAgICBjb25zdCBvbkNsaWNrQnV0dG9uID0gKCkgPT4ge1xuICAgICAgICBzZXRDb3VudCgocHJldikgPT4gcHJldiArIDEpO1xuICAgIH07XG5cbiAgICBjb25zdCBvbkNsaWNrTW92ZSA9ICgpID0+IHtcbiAgICAgICAgcm91dGVyLnB1c2goXCIvXCIpO1xuICAgIH07XG5cbiAgICBjb25zb2xlLmxvZyhcIuuniOyatO2KuCDsi5zsnpFcIik7XG4gICAgcmV0dXJuIChcbiAgICAgICAgPD5cbiAgICAgICAgICAgIDxkaXY+7Lm07Jq07Yq4OiB7Y291bnR9PC9kaXY+XG4gICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e29uQ2xpY2tCdXR0b259Puy5tOyatO2KuCgrMSk8L2J1dHRvbj5cbiAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17b25DbGlja01vdmV9PuydtOuPme2VmOq4sDwvYnV0dG9uPlxuICAgICAgICA8Lz5cbiAgICApO1xufVxuIl0sIm5hbWVzIjpbInVzZVJvdXRlciIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiTXlDb21wb25lbnQiLCJjb3VudCIsInNldENvdW50Iiwicm91dGVyIiwiY29uc29sZSIsImxvZyIsImFsZXJ0Iiwicm91dGUiLCJvbkNsaWNrQnV0dG9uIiwicHJldiIsIm9uQ2xpY2tNb3ZlIiwicHVzaCIsImRpdiIsImJ1dHRvbiIsIm9uQ2xpY2siXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/17-2/index.tsx\n");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/17-2/index.tsx"));
module.exports = __webpack_exports__;

})();