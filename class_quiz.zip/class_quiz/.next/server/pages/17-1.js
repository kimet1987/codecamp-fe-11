"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/17-1";
exports.ids = ["pages/17-1"];
exports.modules = {

/***/ "./pages/17-1/index.tsx":
/*!******************************!*\
  !*** ./pages/17-1/index.tsx ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ ChangePage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nfunction ChangePage() {\n    const { 0: isChanged , 1: setIsChanged  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();\n    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{\n        alert(\"Rendered\");\n    }, []);\n    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{\n        alert(\"Changed!!\");\n    }, [\n        isChanged\n    ]);\n    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{\n        return ()=>{\n            alert(\"Bye!!\");\n        };\n    }, [\n        router.route\n    ]);\n    const onMove = ()=>{\n        router.push(\"/\");\n    };\n    const onChange = ()=>{\n        setIsChanged(true);\n    };\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: onChange,\n                children: \"변경\"\n            }, void 0, false, {\n                fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/pages/17-1/index.tsx\",\n                lineNumber: 31,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: onMove,\n                children: \"이동\"\n            }, void 0, false, {\n                fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/pages/17-1/index.tsx\",\n                lineNumber: 32,\n                columnNumber: 13\n            }, this)\n        ]\n    }, void 0, true));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8xNy0xL2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUF1QztBQUNJO0FBRTVCLFFBQVEsQ0FBQ0csVUFBVSxHQUFnQixDQUFDO0lBQy9DLEtBQUssTUFBRUMsU0FBUyxNQUFFQyxZQUFZLE1BQUlILCtDQUFRLENBQUMsS0FBSztJQUNoRCxLQUFLLENBQUNJLE1BQU0sR0FBR04sc0RBQVM7SUFFeEJDLGdEQUFTLEtBQU8sQ0FBQztRQUNiTSxLQUFLLENBQUMsQ0FBVTtJQUNwQixDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBRUxOLGdEQUFTLEtBQU8sQ0FBQztRQUNiTSxLQUFLLENBQUMsQ0FBVztJQUNyQixDQUFDLEVBQUUsQ0FBQ0g7UUFBQUEsU0FBUztJQUFBLENBQUM7SUFFZEgsZ0RBQVMsS0FBTyxDQUFDO1FBQ2IsTUFBTSxLQUFPLENBQUM7WUFDVk0sS0FBSyxDQUFDLENBQU87UUFDakIsQ0FBQztJQUNMLENBQUMsRUFBRSxDQUFDRDtRQUFBQSxNQUFNLENBQUNFLEtBQUs7SUFBQSxDQUFDO0lBRWpCLEtBQUssQ0FBQ0MsTUFBTSxPQUFTLENBQUM7UUFDbEJILE1BQU0sQ0FBQ0ksSUFBSSxDQUFDLENBQUc7SUFDbkIsQ0FBQztJQUNELEtBQUssQ0FBQ0MsUUFBUSxPQUFTLENBQUM7UUFDcEJOLFlBQVksQ0FBQyxJQUFJO0lBQ3JCLENBQUM7SUFFRCxNQUFNOzt3RkFFR08sQ0FBTTtnQkFBQ0MsT0FBTyxFQUFFRixRQUFROzBCQUFFLENBQUU7Ozs7Ozt3RkFDeEJDLENBQUU7Z0JBQUNDLE9BQU8sRUFBRUosTUFBTTswQkFBRSxDQUFFOzs7Ozs7OztBQUd2QyxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3NfcXVpei8uL3BhZ2VzLzE3LTEvaW5kZXgudHN4PzJlODUiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIm5leHQvcm91dGVyXCI7XG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENoYW5nZVBhZ2UoKTogSlNYLkVsZW1lbnQge1xuICAgIGNvbnN0IFtpc0NoYW5nZWQsIHNldElzQ2hhbmdlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBhbGVydChcIlJlbmRlcmVkXCIpO1xuICAgIH0sIFtdKTtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGFsZXJ0KFwiQ2hhbmdlZCEhXCIpO1xuICAgIH0sIFtpc0NoYW5nZWRdKTtcblxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgICBhbGVydChcIkJ5ZSEhXCIpO1xuICAgICAgICB9O1xuICAgIH0sIFtyb3V0ZXIucm91dGVdKTtcblxuICAgIGNvbnN0IG9uTW92ZSA9ICgpID0+IHtcbiAgICAgICAgcm91dGVyLnB1c2goXCIvXCIpO1xuICAgIH07XG4gICAgY29uc3Qgb25DaGFuZ2UgPSAoKSA9PiB7XG4gICAgICAgIHNldElzQ2hhbmdlZCh0cnVlKTtcbiAgICB9O1xuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPD5cbiAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17b25DaGFuZ2V9PuuzgOqyvTwvYnV0dG9uPlxuICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtvbk1vdmV9PuydtOuPmTwvYnV0dG9uPlxuICAgICAgICA8Lz5cbiAgICApO1xufVxuIl0sIm5hbWVzIjpbInVzZVJvdXRlciIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiQ2hhbmdlUGFnZSIsImlzQ2hhbmdlZCIsInNldElzQ2hhbmdlZCIsInJvdXRlciIsImFsZXJ0Iiwicm91dGUiLCJvbk1vdmUiLCJwdXNoIiwib25DaGFuZ2UiLCJidXR0b24iLCJvbkNsaWNrIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/17-1/index.tsx\n");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/17-1/index.tsx"));
module.exports = __webpack_exports__;

})();