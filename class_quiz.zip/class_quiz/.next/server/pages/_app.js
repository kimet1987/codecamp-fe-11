/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./pages/14/index.tsx":
/*!****************************!*\
  !*** ./pages/14/index.tsx ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Layout)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _src_Layout_Banner__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../src/Layout/Banner */ \"./src/Layout/Banner/index.tsx\");\n/* harmony import */ var _src_Layout_Footer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../src/Layout/Footer */ \"./src/Layout/Footer/index.tsx\");\n/* harmony import */ var _src_Layout_Header__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../src/Layout/Header */ \"./src/Layout/Header/index.tsx\");\n/* harmony import */ var _src_Layout_Side__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../src/Layout/Side */ \"./src/Layout/Side/index.tsx\");\n/* harmony import */ var _navi__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./navi */ \"./pages/14/navi/index.tsx\");\n\n\n\n\n\n\n\nfunction Layout(props) {\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();\n    console.log(router.asPath);\n    //const isTextChange = TEXT_CHANGE.includes(router.asPath);\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_src_Layout_Header__WEBPACK_IMPORTED_MODULE_4__[\"default\"], {}, void 0, false, {\n                fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/pages/14/index.tsx\",\n                lineNumber: 23,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_navi__WEBPACK_IMPORTED_MODULE_6__[\"default\"], {}, void 0, false, {\n                fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/pages/14/index.tsx\",\n                lineNumber: 24,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_src_Layout_Banner__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {}, void 0, false, {\n                fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/pages/14/index.tsx\",\n                lineNumber: 25,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                style: {\n                    width: \"100%\",\n                    height: \"fit-content\",\n                    display: \"flex\"\n                },\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_src_Layout_Side__WEBPACK_IMPORTED_MODULE_5__[\"default\"], {}, void 0, false, {\n                        fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/pages/14/index.tsx\",\n                        lineNumber: 34,\n                        columnNumber: 17\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                        style: {\n                            width: \"70%\",\n                            height: \"500px\",\n                            overflow: \"auto\"\n                        },\n                        children: props.children\n                    }, void 0, false, {\n                        fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/pages/14/index.tsx\",\n                        lineNumber: 42,\n                        columnNumber: 17\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/pages/14/index.tsx\",\n                lineNumber: 27,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_src_Layout_Footer__WEBPACK_IMPORTED_MODULE_3__[\"default\"], {}, void 0, false, {\n                fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/pages/14/index.tsx\",\n                lineNumber: 48,\n                columnNumber: 13\n            }, this)\n        ]\n    }, void 0, true));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8xNC9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7QUFBdUM7QUFDSztBQUVBO0FBQ0E7QUFFSjtBQUNmO0FBT1YsUUFBUSxDQUFDTSxNQUFNLENBQUNDLEtBQWMsRUFBZSxDQUFDO0lBQ3pELEtBQUssQ0FBQ0MsTUFBTSxHQUFHUixzREFBUztJQUN4QlMsT0FBTyxDQUFDQyxHQUFHLENBQUNGLE1BQU0sQ0FBQ0csTUFBTTtJQUV6QixFQUEyRDtJQUUzRCxNQUFNOzt3RkFFR1IsMERBQU07Ozs7O3dGQUNORSw2Q0FBSTs7Ozs7d0ZBQ0pKLDBEQUFNOzs7Ozt3RkFFTlcsQ0FBRztnQkFDQUMsS0FBSyxFQUFFLENBQUM7b0JBQ0pDLEtBQUssRUFBRSxDQUFNO29CQUNiQyxNQUFNLEVBQUUsQ0FBYTtvQkFDckJDLE9BQU8sRUFBRSxDQUFNO2dCQUNuQixDQUFDOztnR0FFQVosd0RBQUk7Ozs7O2dHQVFKUSxDQUFHO3dCQUNBQyxLQUFLLEVBQUUsQ0FBQzs0QkFBQ0MsS0FBSyxFQUFFLENBQUs7NEJBQUVDLE1BQU0sRUFBRSxDQUFPOzRCQUFFRSxRQUFRLEVBQUUsQ0FBTTt3QkFBQyxDQUFDO2tDQUV6RFYsS0FBSyxDQUFDVyxRQUFROzs7Ozs7Ozs7Ozs7d0ZBR3RCaEIsMERBQU07Ozs7Ozs7QUFHbkIsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzX3F1aXovLi9wYWdlcy8xNC9pbmRleC50c3g/MTMzNSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcbmltcG9ydCBCYW5uZXIgZnJvbSBcIi4uLy4uL3NyYy9MYXlvdXQvQmFubmVyXCI7XG5pbXBvcnQgQm9keSBmcm9tIFwiLi4vLi4vc3JjL0xheW91dC9Cb2R5XCI7XG5pbXBvcnQgRm9vdGVyIGZyb20gXCIuLi8uLi9zcmMvTGF5b3V0L0Zvb3RlclwiO1xuaW1wb3J0IEhlYWRlciBmcm9tIFwiLi4vLi4vc3JjL0xheW91dC9IZWFkZXJcIjtcbmltcG9ydCBOYXZpZ2F0aW9uIGZyb20gXCIuLi8uLi9zcmMvTGF5b3V0L05hdmlnYXRpb25cIjtcbmltcG9ydCBTaWRlIGZyb20gXCIuLi8uLi9zcmMvTGF5b3V0L1NpZGVcIjtcbmltcG9ydCBOYXZpIGZyb20gXCIuL25hdmlcIjtcblxuLy8gY29uc3QgVEVYVF9DSEFOR0UgPSBbXCIvMTQvb25lXCIsIFwiLzE0L3R3b1wiLCBcIi8xNC90aHJlZVwiXTtcbmludGVyZmFjZSBJTGF5b3V0IHtcbiAgICBjaGlsZHJlbjogSlNYLkVsZW1lbnQ7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIExheW91dChwcm9wczogSUxheW91dCk6IEpTWC5FbGVtZW50IHtcbiAgICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcbiAgICBjb25zb2xlLmxvZyhyb3V0ZXIuYXNQYXRoKTtcblxuICAgIC8vY29uc3QgaXNUZXh0Q2hhbmdlID0gVEVYVF9DSEFOR0UuaW5jbHVkZXMocm91dGVyLmFzUGF0aCk7XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8PlxuICAgICAgICAgICAgPEhlYWRlciAvPlxuICAgICAgICAgICAgPE5hdmkgLz5cbiAgICAgICAgICAgIDxCYW5uZXIgLz5cbiAgICAgICAgICAgIHsvKiA8TmF2aWdhdGlvbiAvPiAqL31cbiAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgICB3aWR0aDogXCIxMDAlXCIsXG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDogXCJmaXQtY29udGVudFwiLFxuICAgICAgICAgICAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxTaWRlIC8+XG4gICAgICAgICAgICAgICAgey8qIHtpc1RleHRDaGFuZ2UgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgd2lkdGg6IFwiNzAlXCIgfX0+e3Byb3BzLmNoaWxkcmVufTwvZGl2PlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgd2lkdGg6IFwiNzAlXCIsIGJhY2tncm91bmRDb2xvcjogXCIjMzMzXCIgfX0+XG4gICAgICAgICAgICAgICAgICAgICAgICDrsJTrlJTsmIHsl60g7J6F64uI64ukXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICl9ICovfVxuICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IFwiNzAlXCIsIGhlaWdodDogXCI1MDBweFwiLCBvdmVyZmxvdzogXCJhdXRvXCIgfX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtwcm9wcy5jaGlsZHJlbn1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPEZvb3RlciAvPlxuICAgICAgICA8Lz5cbiAgICApO1xufVxuIl0sIm5hbWVzIjpbInVzZVJvdXRlciIsIkJhbm5lciIsIkZvb3RlciIsIkhlYWRlciIsIlNpZGUiLCJOYXZpIiwiTGF5b3V0IiwicHJvcHMiLCJyb3V0ZXIiLCJjb25zb2xlIiwibG9nIiwiYXNQYXRoIiwiZGl2Iiwic3R5bGUiLCJ3aWR0aCIsImhlaWdodCIsImRpc3BsYXkiLCJvdmVyZmxvdyIsImNoaWxkcmVuIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/14/index.tsx\n");

/***/ }),

/***/ "./pages/14/navi/index.tsx":
/*!*********************************!*\
  !*** ./pages/14/navi/index.tsx ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"Wrapper\": () => (/* binding */ Wrapper),\n/* harmony export */   \"default\": () => (/* binding */ Navi)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-slick */ \"react-slick\");\n/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! slick-carousel/slick/slick.css */ \"./node_modules/slick-carousel/slick/slick.css\");\n/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! slick-carousel/slick/slick-theme.css */ \"./node_modules/slick-carousel/slick/slick-theme.css\");\n/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_5__);\n\n\n\n\n\n\nconst Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_5___default().div)`\n    height: 300px;\n    .slick-slider {\n        position: relative;\n        height: 100%;\n        width: 80%;\n        margin: 0 auto;\n    }\n    .slick-arrow {\n        background-color: tomato;\n    }\n    .slick-dots {\n        position: absolute;\n        bottom: 0;\n        left: 50%;\n        transform: translateX(-50%);\n    }\n`;\nfunction Navi() {\n    const settings = {\n        dots: true,\n        speed: 500,\n        slidesToShow: 1,\n        slidesToScroll: 1\n    };\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Wrapper, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((react_slick__WEBPACK_IMPORTED_MODULE_2___default()), {\n            ...settings,\n            children: [\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h3\", {\n                        children: \"1\"\n                    }, void 0, false, {\n                        fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/pages/14/navi/index.tsx\",\n                        lineNumber: 36,\n                        columnNumber: 21\n                    }, this)\n                }, void 0, false, {\n                    fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/pages/14/navi/index.tsx\",\n                    lineNumber: 35,\n                    columnNumber: 17\n                }, this),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h3\", {\n                        children: \"2\"\n                    }, void 0, false, {\n                        fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/pages/14/navi/index.tsx\",\n                        lineNumber: 39,\n                        columnNumber: 21\n                    }, this)\n                }, void 0, false, {\n                    fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/pages/14/navi/index.tsx\",\n                    lineNumber: 38,\n                    columnNumber: 17\n                }, this),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h3\", {\n                        children: \"3\"\n                    }, void 0, false, {\n                        fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/pages/14/navi/index.tsx\",\n                        lineNumber: 42,\n                        columnNumber: 21\n                    }, this)\n                }, void 0, false, {\n                    fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/pages/14/navi/index.tsx\",\n                    lineNumber: 41,\n                    columnNumber: 17\n                }, this),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h3\", {\n                        children: \"4\"\n                    }, void 0, false, {\n                        fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/pages/14/navi/index.tsx\",\n                        lineNumber: 45,\n                        columnNumber: 21\n                    }, this)\n                }, void 0, false, {\n                    fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/pages/14/navi/index.tsx\",\n                    lineNumber: 44,\n                    columnNumber: 17\n                }, this),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h3\", {\n                        children: \"5\"\n                    }, void 0, false, {\n                        fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/pages/14/navi/index.tsx\",\n                        lineNumber: 48,\n                        columnNumber: 21\n                    }, this)\n                }, void 0, false, {\n                    fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/pages/14/navi/index.tsx\",\n                    lineNumber: 47,\n                    columnNumber: 17\n                }, this),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h3\", {\n                        children: \"6\"\n                    }, void 0, false, {\n                        fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/pages/14/navi/index.tsx\",\n                        lineNumber: 51,\n                        columnNumber: 21\n                    }, this)\n                }, void 0, false, {\n                    fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/pages/14/navi/index.tsx\",\n                    lineNumber: 50,\n                    columnNumber: 17\n                }, this)\n            ]\n        }, void 0, true, {\n            fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/pages/14/navi/index.tsx\",\n            lineNumber: 34,\n            columnNumber: 13\n        }, this)\n    }, void 0, false, {\n        fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/pages/14/navi/index.tsx\",\n        lineNumber: 33,\n        columnNumber: 9\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8xNC9uYXZpL2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBeUI7QUFDTztBQUNPO0FBQ007QUFDVDtBQUM3QixLQUFLLENBQUNHLE9BQU8sR0FBR0QsNERBQVUsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFpQmxDO0FBRWUsUUFBUSxDQUFDRyxJQUFJLEdBQUcsQ0FBQztJQUM1QixLQUFLLENBQUNDLFFBQVEsR0FBRyxDQUFDO1FBQ2RDLElBQUksRUFBRSxJQUFJO1FBQ1ZDLEtBQUssRUFBRSxHQUFHO1FBQ1ZDLFlBQVksRUFBRSxDQUFDO1FBQ2ZDLGNBQWMsRUFBRSxDQUFDO0lBQ3JCLENBQUM7SUFDRCxNQUFNLDZFQUNEUCxPQUFPOzhGQUNIRixvREFBTTtlQUFLSyxRQUFROzs0RkFDZkYsQ0FBRzswR0FDQ08sQ0FBRTtrQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs0RkFFUlAsQ0FBRzswR0FDQ08sQ0FBRTtrQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs0RkFFUlAsQ0FBRzswR0FDQ08sQ0FBRTtrQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs0RkFFUlAsQ0FBRzswR0FDQ08sQ0FBRTtrQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs0RkFFUlAsQ0FBRzswR0FDQ08sQ0FBRTtrQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs0RkFFUlAsQ0FBRzswR0FDQ08sQ0FBRTtrQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBS3pCLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jbGFzc19xdWl6Ly4vcGFnZXMvMTQvbmF2aS9pbmRleC50c3g/YzVkNyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgU2xpZGVyIGZyb20gXCJyZWFjdC1zbGlja1wiO1xuaW1wb3J0IFwic2xpY2stY2Fyb3VzZWwvc2xpY2svc2xpY2suY3NzXCI7XG5pbXBvcnQgXCJzbGljay1jYXJvdXNlbC9zbGljay9zbGljay10aGVtZS5jc3NcIjtcbmltcG9ydCBzdHlsZWQgZnJvbSBcIkBlbW90aW9uL3N0eWxlZFwiO1xuZXhwb3J0IGNvbnN0IFdyYXBwZXIgPSBzdHlsZWQuZGl2YFxuICAgIGhlaWdodDogMzAwcHg7XG4gICAgLnNsaWNrLXNsaWRlciB7XG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICAgICAgaGVpZ2h0OiAxMDAlO1xuICAgICAgICB3aWR0aDogODAlO1xuICAgICAgICBtYXJnaW46IDAgYXV0bztcbiAgICB9XG4gICAgLnNsaWNrLWFycm93IHtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdG9tYXRvO1xuICAgIH1cbiAgICAuc2xpY2stZG90cyB7XG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgYm90dG9tOiAwO1xuICAgICAgICBsZWZ0OiA1MCU7XG4gICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWCgtNTAlKTtcbiAgICB9XG5gO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBOYXZpKCkge1xuICAgIGNvbnN0IHNldHRpbmdzID0ge1xuICAgICAgICBkb3RzOiB0cnVlLFxuICAgICAgICBzcGVlZDogNTAwLFxuICAgICAgICBzbGlkZXNUb1Nob3c6IDEsXG4gICAgICAgIHNsaWRlc1RvU2Nyb2xsOiAxLFxuICAgIH07XG4gICAgcmV0dXJuIChcbiAgICAgICAgPFdyYXBwZXI+XG4gICAgICAgICAgICA8U2xpZGVyIHsuLi5zZXR0aW5nc30+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGgzPjE8L2gzPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxoMz4yPC9oMz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8aDM+MzwvaDM+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGgzPjQ8L2gzPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxoMz41PC9oMz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8aDM+NjwvaDM+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L1NsaWRlcj5cbiAgICAgICAgPC9XcmFwcGVyPlxuICAgICk7XG59XG4iXSwibmFtZXMiOlsiUmVhY3QiLCJTbGlkZXIiLCJzdHlsZWQiLCJXcmFwcGVyIiwiZGl2IiwiTmF2aSIsInNldHRpbmdzIiwiZG90cyIsInNwZWVkIiwic2xpZGVzVG9TaG93Iiwic2xpZGVzVG9TY3JvbGwiLCJoMyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/14/navi/index.tsx\n");

/***/ }),

/***/ "./pages/_app.tsx":
/*!************************!*\
  !*** ./pages/_app.tsx ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ App)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @emotion/react */ \"@emotion/react\");\n/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_emotion_react__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var swiper_css_bundle__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! swiper/css/bundle */ \"./node_modules/swiper/swiper-bundle.min.css\");\n/* harmony import */ var swiper_css_bundle__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(swiper_css_bundle__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _src_commons_styles_globalStyle__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../src/commons/styles/globalStyle */ \"./src/commons/styles/globalStyle.ts\");\n/* harmony import */ var _14__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./14 */ \"./pages/14/index.tsx\");\n\n\n\n\n\n\nfunction App({ Component  }) {\n    const client = new _apollo_client__WEBPACK_IMPORTED_MODULE_1__.ApolloClient({\n        uri: \"http://backend-example.codebootcamp.co.kr/graphql\",\n        cache: new _apollo_client__WEBPACK_IMPORTED_MODULE_1__.InMemoryCache()\n    });\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_apollo_client__WEBPACK_IMPORTED_MODULE_1__.ApolloProvider, {\n        client: client,\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n            children: [\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_emotion_react__WEBPACK_IMPORTED_MODULE_2__.Global, {\n                    styles: _src_commons_styles_globalStyle__WEBPACK_IMPORTED_MODULE_4__.globalStyles\n                }, void 0, false, {\n                    fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/pages/_app.tsx\",\n                    lineNumber: 16,\n                    columnNumber: 17\n                }, this),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_14__WEBPACK_IMPORTED_MODULE_5__[\"default\"], {\n                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {}, void 0, false, {\n                        fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/pages/_app.tsx\",\n                        lineNumber: 18,\n                        columnNumber: 21\n                    }, this)\n                }, void 0, false, {\n                    fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/pages/_app.tsx\",\n                    lineNumber: 17,\n                    columnNumber: 17\n                }, this)\n            ]\n        }, void 0, true)\n    }, void 0, false, {\n        fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/pages/_app.tsx\",\n        lineNumber: 14,\n        columnNumber: 9\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7QUFBNEU7QUFDckM7QUFFYjtBQUNzQztBQUN2QztBQUVWLFFBQVEsQ0FBQ00sR0FBRyxDQUFDLENBQUMsQ0FBQ0MsU0FBUyxFQUFXLENBQUMsRUFBZSxDQUFDO0lBQy9ELEtBQUssQ0FBQ0MsTUFBTSxHQUFHLEdBQUcsQ0FBQ1Isd0RBQVksQ0FBQyxDQUFDO1FBQzdCUyxHQUFHLEVBQUUsQ0FBbUQ7UUFDeERDLEtBQUssRUFBRSxHQUFHLENBQUNSLHlEQUFhO0lBQzVCLENBQUM7SUFDRCxNQUFNLDZFQUNERCwwREFBYztRQUFDTyxNQUFNLEVBQUVBLE1BQU07Ozs0RkFFckJMLGtEQUFNO29CQUFDUSxNQUFNLEVBQUVQLHlFQUFZOzs7Ozs7NEZBQzNCQywyQ0FBTTswR0FDRkUsU0FBUzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFLOUIsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzX3F1aXovLi9wYWdlcy9fYXBwLnRzeD8yZmJlIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFwb2xsb0NsaWVudCwgQXBvbGxvUHJvdmlkZXIsIEluTWVtb3J5Q2FjaGUgfSBmcm9tIFwiQGFwb2xsby9jbGllbnRcIjtcbmltcG9ydCB7IEdsb2JhbCB9IGZyb20gXCJAZW1vdGlvbi9yZWFjdFwiO1xuaW1wb3J0IHsgQXBwUHJvcHMgfSBmcm9tIFwibmV4dC9hcHBcIjtcbmltcG9ydCBcInN3aXBlci9jc3MvYnVuZGxlXCI7XG5pbXBvcnQgeyBnbG9iYWxTdHlsZXMgfSBmcm9tIFwiLi4vc3JjL2NvbW1vbnMvc3R5bGVzL2dsb2JhbFN0eWxlXCI7XG5pbXBvcnQgTGF5b3V0IGZyb20gXCIuLzE0XCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFwcCh7IENvbXBvbmVudCB9OiBBcHBQcm9wcyk6IEpTWC5FbGVtZW50IHtcbiAgICBjb25zdCBjbGllbnQgPSBuZXcgQXBvbGxvQ2xpZW50KHtcbiAgICAgICAgdXJpOiBcImh0dHA6Ly9iYWNrZW5kLWV4YW1wbGUuY29kZWJvb3RjYW1wLmNvLmtyL2dyYXBocWxcIixcbiAgICAgICAgY2FjaGU6IG5ldyBJbk1lbW9yeUNhY2hlKCksXG4gICAgfSk7XG4gICAgcmV0dXJuIChcbiAgICAgICAgPEFwb2xsb1Byb3ZpZGVyIGNsaWVudD17Y2xpZW50fT5cbiAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgPEdsb2JhbCBzdHlsZXM9e2dsb2JhbFN0eWxlc30gLz5cbiAgICAgICAgICAgICAgICA8TGF5b3V0PlxuICAgICAgICAgICAgICAgICAgICA8Q29tcG9uZW50IC8+XG4gICAgICAgICAgICAgICAgPC9MYXlvdXQ+XG4gICAgICAgICAgICA8Lz5cbiAgICAgICAgPC9BcG9sbG9Qcm92aWRlcj5cbiAgICApO1xufVxuIl0sIm5hbWVzIjpbIkFwb2xsb0NsaWVudCIsIkFwb2xsb1Byb3ZpZGVyIiwiSW5NZW1vcnlDYWNoZSIsIkdsb2JhbCIsImdsb2JhbFN0eWxlcyIsIkxheW91dCIsIkFwcCIsIkNvbXBvbmVudCIsImNsaWVudCIsInVyaSIsImNhY2hlIiwic3R5bGVzIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/_app.tsx\n");

/***/ }),

/***/ "./src/Layout/Banner/index.tsx":
/*!*************************************!*\
  !*** ./src/Layout/Banner/index.tsx ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Banner)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n    height: 150px;\n    background-color: pink;\n`;\nfunction Banner() {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Wrapper, {\n        children: \"배너영역 입니다\"\n    }, void 0, false, {\n        fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/src/Layout/Banner/index.tsx\",\n        lineNumber: 8,\n        columnNumber: 12\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvTGF5b3V0L0Jhbm5lci9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQW9DO0FBQ3BDLEtBQUssQ0FBQ0MsT0FBTyxHQUFHRCw0REFBVSxDQUFDOzs7QUFHM0I7QUFFZSxRQUFRLENBQUNHLE1BQU0sR0FBZ0IsQ0FBQztJQUMzQyxNQUFNLDZFQUFFRixPQUFPO2tCQUFDLENBQVE7Ozs7OztBQUM1QixDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3NfcXVpei8uL3NyYy9MYXlvdXQvQmFubmVyL2luZGV4LnRzeD82NWZmIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBzdHlsZWQgZnJvbSBcIkBlbW90aW9uL3N0eWxlZFwiO1xuY29uc3QgV3JhcHBlciA9IHN0eWxlZC5kaXZgXG4gICAgaGVpZ2h0OiAxNTBweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiBwaW5rO1xuYDtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQmFubmVyKCk6IEpTWC5FbGVtZW50IHtcbiAgICByZXR1cm4gPFdyYXBwZXI+67Cw64SI7JiB7JetIOyeheuLiOuLpDwvV3JhcHBlcj47XG59XG4iXSwibmFtZXMiOlsic3R5bGVkIiwiV3JhcHBlciIsImRpdiIsIkJhbm5lciJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/Layout/Banner/index.tsx\n");

/***/ }),

/***/ "./src/Layout/Footer/index.tsx":
/*!*************************************!*\
  !*** ./src/Layout/Footer/index.tsx ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Footer)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n    height: 100px;\n    background-color: #b6eb87;\n`;\nfunction Footer() {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Wrapper, {\n        children: \"여기는 풋터입니다\"\n    }, void 0, false, {\n        fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/src/Layout/Footer/index.tsx\",\n        lineNumber: 8,\n        columnNumber: 12\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvTGF5b3V0L0Zvb3Rlci9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQW9DO0FBQ3BDLEtBQUssQ0FBQ0MsT0FBTyxHQUFHRCw0REFBVSxDQUFDOzs7QUFHM0I7QUFFZSxRQUFRLENBQUNHLE1BQU0sR0FBZ0IsQ0FBQztJQUMzQyxNQUFNLDZFQUFFRixPQUFPO2tCQUFDLENBQVM7Ozs7OztBQUM3QixDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3NfcXVpei8uL3NyYy9MYXlvdXQvRm9vdGVyL2luZGV4LnRzeD9iODcxIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBzdHlsZWQgZnJvbSBcIkBlbW90aW9uL3N0eWxlZFwiO1xuY29uc3QgV3JhcHBlciA9IHN0eWxlZC5kaXZgXG4gICAgaGVpZ2h0OiAxMDBweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjYjZlYjg3O1xuYDtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gRm9vdGVyKCk6IEpTWC5FbGVtZW50IHtcbiAgICByZXR1cm4gPFdyYXBwZXI+7Jes6riw64qUIO2Si+2EsOyeheuLiOuLpDwvV3JhcHBlcj47XG59XG4iXSwibmFtZXMiOlsic3R5bGVkIiwiV3JhcHBlciIsImRpdiIsIkZvb3RlciJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/Layout/Footer/index.tsx\n");

/***/ }),

/***/ "./src/Layout/Header/index.tsx":
/*!*************************************!*\
  !*** ./src/Layout/Header/index.tsx ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Header)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n    height: 50px;\n    background-color: tomato;\n`;\nfunction Header() {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Wrapper, {\n        children: \"헤더영역 입니다\"\n    }, void 0, false, {\n        fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/src/Layout/Header/index.tsx\",\n        lineNumber: 8,\n        columnNumber: 12\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvTGF5b3V0L0hlYWRlci9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQW9DO0FBQ3BDLEtBQUssQ0FBQ0MsT0FBTyxHQUFHRCw0REFBVSxDQUFDOzs7QUFHM0I7QUFFZSxRQUFRLENBQUNHLE1BQU0sR0FBZ0IsQ0FBQztJQUMzQyxNQUFNLDZFQUFFRixPQUFPO2tCQUFDLENBQVE7Ozs7OztBQUM1QixDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3NfcXVpei8uL3NyYy9MYXlvdXQvSGVhZGVyL2luZGV4LnRzeD82ZmJmIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBzdHlsZWQgZnJvbSBcIkBlbW90aW9uL3N0eWxlZFwiO1xuY29uc3QgV3JhcHBlciA9IHN0eWxlZC5kaXZgXG4gICAgaGVpZ2h0OiA1MHB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6IHRvbWF0bztcbmA7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEhlYWRlcigpOiBKU1guRWxlbWVudCB7XG4gICAgcmV0dXJuIDxXcmFwcGVyPu2XpOuNlOyYgeyXrSDsnoXri4jri6Q8L1dyYXBwZXI+O1xufVxuIl0sIm5hbWVzIjpbInN0eWxlZCIsIldyYXBwZXIiLCJkaXYiLCJIZWFkZXIiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/Layout/Header/index.tsx\n");

/***/ }),

/***/ "./src/Layout/Side/index.tsx":
/*!***********************************!*\
  !*** ./src/Layout/Side/index.tsx ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Side)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n    width: 30%;\n    background-color: skyblue;\n`;\nfunction Side() {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Wrapper, {\n        children: \"사이드영역 입니다\"\n    }, void 0, false, {\n        fileName: \"/Users/thebyoungsoo/Desktop/codecamp_11FE_byoungsu/class_quiz/src/Layout/Side/index.tsx\",\n        lineNumber: 8,\n        columnNumber: 12\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvTGF5b3V0L1NpZGUvaW5kZXgudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFvQztBQUNwQyxLQUFLLENBQUNDLE9BQU8sR0FBR0QsNERBQVUsQ0FBQzs7O0FBRzNCO0FBRWUsUUFBUSxDQUFDRyxJQUFJLEdBQWdCLENBQUM7SUFDekMsTUFBTSw2RUFBRUYsT0FBTztrQkFBQyxDQUFTOzs7Ozs7QUFDN0IsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzX3F1aXovLi9zcmMvTGF5b3V0L1NpZGUvaW5kZXgudHN4Pzc5MzUiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHN0eWxlZCBmcm9tIFwiQGVtb3Rpb24vc3R5bGVkXCI7XG5jb25zdCBXcmFwcGVyID0gc3R5bGVkLmRpdmBcbiAgICB3aWR0aDogMzAlO1xuICAgIGJhY2tncm91bmQtY29sb3I6IHNreWJsdWU7XG5gO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTaWRlKCk6IEpTWC5FbGVtZW50IHtcbiAgICByZXR1cm4gPFdyYXBwZXI+7IKs7J2065Oc7JiB7JetIOyeheuLiOuLpDwvV3JhcHBlcj47XG59XG4iXSwibmFtZXMiOlsic3R5bGVkIiwiV3JhcHBlciIsImRpdiIsIlNpZGUiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/Layout/Side/index.tsx\n");

/***/ }),

/***/ "./src/commons/styles/globalStyle.ts":
/*!*******************************************!*\
  !*** ./src/commons/styles/globalStyle.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"globalStyles\": () => (/* binding */ globalStyles)\n/* harmony export */ });\n/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/react */ \"@emotion/react\");\n/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_emotion_react__WEBPACK_IMPORTED_MODULE_0__);\n\nconst globalStyles = _emotion_react__WEBPACK_IMPORTED_MODULE_0__.css`\n    * {\n        margin: 0;\n        box-sizing: border-box;\n        font-size: 30px;\n    }\n    @font-face {\n        font-family: \"quiz\";\n        src: url(\"/fonts/scifibit.ttf\");\n    }\n`;\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tbW9ucy9zdHlsZXMvZ2xvYmFsU3R5bGUudHMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQW9DO0FBRTdCLEtBQUssQ0FBQ0MsWUFBWSxHQUFHRCwrQ0FBRyxDQUFDOzs7Ozs7Ozs7O0FBVWhDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3NfcXVpei8uL3NyYy9jb21tb25zL3N0eWxlcy9nbG9iYWxTdHlsZS50cz8yYmJkIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNzcyB9IGZyb20gXCJAZW1vdGlvbi9yZWFjdFwiO1xuXG5leHBvcnQgY29uc3QgZ2xvYmFsU3R5bGVzID0gY3NzYFxuICAgICoge1xuICAgICAgICBtYXJnaW46IDA7XG4gICAgICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gICAgICAgIGZvbnQtc2l6ZTogMzBweDtcbiAgICB9XG4gICAgQGZvbnQtZmFjZSB7XG4gICAgICAgIGZvbnQtZmFtaWx5OiBcInF1aXpcIjtcbiAgICAgICAgc3JjOiB1cmwoXCIvZm9udHMvc2NpZmliaXQudHRmXCIpO1xuICAgIH1cbmA7XG4iXSwibmFtZXMiOlsiY3NzIiwiZ2xvYmFsU3R5bGVzIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/commons/styles/globalStyle.ts\n");

/***/ }),

/***/ "./node_modules/slick-carousel/slick/slick-theme.css":
/*!***********************************************************!*\
  !*** ./node_modules/slick-carousel/slick/slick-theme.css ***!
  \***********************************************************/
/***/ (() => {



/***/ }),

/***/ "./node_modules/slick-carousel/slick/slick.css":
/*!*****************************************************!*\
  !*** ./node_modules/slick-carousel/slick/slick.css ***!
  \*****************************************************/
/***/ (() => {



/***/ }),

/***/ "./node_modules/swiper/swiper-bundle.min.css":
/*!***************************************************!*\
  !*** ./node_modules/swiper/swiper-bundle.min.css ***!
  \***************************************************/
/***/ (() => {



/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@apollo/client");

/***/ }),

/***/ "@emotion/react":
/*!*********************************!*\
  !*** external "@emotion/react" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@emotion/react");

/***/ }),

/***/ "@emotion/styled":
/*!**********************************!*\
  !*** external "@emotion/styled" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@emotion/styled");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react-slick":
/*!******************************!*\
  !*** external "react-slick" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-slick");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.tsx"));
module.exports = __webpack_exports__;

})();