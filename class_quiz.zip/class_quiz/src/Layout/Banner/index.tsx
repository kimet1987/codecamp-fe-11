import styled from "@emotion/styled";
const Wrapper = styled.div`
    height: 150px;
    background-color: pink;
`;

export default function Banner(): JSX.Element {
    return <Wrapper>배너영역 입니다</Wrapper>;
}
