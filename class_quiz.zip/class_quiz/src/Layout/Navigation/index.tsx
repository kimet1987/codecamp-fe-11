import styled from "@emotion/styled";
const Wrapper = styled.div`
    height: 50px;
    background-color: brown;
    font-family: "quiz";
`;

export default function Navigation(): JSX.Element {
    return <Wrapper>네비게이션영역 입니다 navigation</Wrapper>;
}
