// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDVssW924SoKLcNRc_dOLOOcC0Nh3mBRks",
  authDomain: "codeproject-528f5.firebaseapp.com",
  projectId: "codeproject-528f5",
  storageBucket: "codeproject-528f5.appspot.com",
  messagingSenderId: "693858715148",
  appId: "1:693858715148:web:d9127956f6b003169b1029",
};

// Initialize Firebase
export const firebaseApp = initializeApp(firebaseConfig);
