import ProdContainer from "./register/Prod.container";

export default function ProductRegister() {
    return <ProdContainer />;
}
