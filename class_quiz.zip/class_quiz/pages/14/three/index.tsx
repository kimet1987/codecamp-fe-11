import styled from "@emotion/styled";
const Wrapper = styled.div`
    height: 100%;
    background-color: #ff47c2;
`;
export default function Three(): JSX.Element {
    return <Wrapper>THREE 영역 입니다</Wrapper>;
}
