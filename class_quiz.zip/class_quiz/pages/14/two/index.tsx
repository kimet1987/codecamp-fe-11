import styled from "@emotion/styled";
const Wrapper = styled.div`
    height: 100%;
    background-color: #4791ff;
`;
export default function Two(): JSX.Element {
    return <Wrapper>TWO 영역 입니다</Wrapper>;
}
