import styled from "@emotion/styled";
const Wrapper = styled.div`
    height: 100%;
    background-color: #f9ff47;
`;
export default function One(): JSX.Element {
    return <Wrapper>ONE 영역 입니다</Wrapper>;
}
