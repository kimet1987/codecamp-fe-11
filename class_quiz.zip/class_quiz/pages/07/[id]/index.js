import MovedPage from "./moved/moved.container";

export default function RegisterMovedPage() {
    return <MovedPage />;
}
