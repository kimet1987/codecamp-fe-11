import ProductContainer from "./register/Product.container";

export default function ProductRegister() {
    return <ProductContainer />;
}
