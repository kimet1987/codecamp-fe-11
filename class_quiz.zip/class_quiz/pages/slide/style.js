import styled from "@emotion/styled";
export const MySlide = styled.div`
    width: 70%;
    height: 700px;
    img {
        object-fit: contain;
    }
`;
