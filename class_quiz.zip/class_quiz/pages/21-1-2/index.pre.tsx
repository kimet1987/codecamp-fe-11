export default function Presenter(props: any) {
    return (
        <div>
            {props.child}는 {props.age}살 입니다.
        </div>
    );
}
