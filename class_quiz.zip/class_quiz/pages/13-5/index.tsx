import React from "react";
import DaumPostcode from "react-daum-postcode";

function SearchAddress() {
    return <DaumPostcode />;
}
export default SearchAddress;
