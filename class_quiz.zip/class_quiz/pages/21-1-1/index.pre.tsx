export default function Presenter(props: any) {
    return <div>{props.child}</div>;
}
