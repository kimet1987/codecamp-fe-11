import Presenter from "./index.pre";

export default function Container() {
    return <>{Presenter({ child: "철수" })}</>;
}
